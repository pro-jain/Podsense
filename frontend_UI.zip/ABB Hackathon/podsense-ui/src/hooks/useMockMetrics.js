import { useState, useEffect } from 'react'

function randomBetween(min, max) {
  return +(Math.random() * (max - min) + min).toFixed(1)
}

function generateMetrics() {
  return {
    cpu: {
      value: randomBetween(18, 87),
      unit: '%',
      topPod: 'api-gateway',
      trend: randomBetween(-5, 8),
    },
    memory: {
      value: randomBetween(30, 78),
      unit: '%',
      topPod: 'postgres-db',
      trend: randomBetween(-3, 6),
    },
    pvc: {
      value: randomBetween(120, 890),
      unit: 'MB/s',
      topPod: 'redis-cache',
      trend: randomBetween(-20, 40),
    },
    network: {
      value: randomBetween(10, 340),
      unit: 'Mbps',
      topPod: 'frontend-svc',
      trend: randomBetween(-10, 25),
    },
  }
}

export default function useMockMetrics(intervalMs = 5000) {
  const [metrics, setMetrics] = useState(generateMetrics())

  useEffect(() => {
    const timer = setInterval(() => {
      setMetrics(generateMetrics())
    }, intervalMs)
    return () => clearInterval(timer)
  }, [intervalMs])

  return metrics
}
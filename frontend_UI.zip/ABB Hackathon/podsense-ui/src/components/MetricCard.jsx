export default function MetricCard({ title, value, unit, topPod, trend, icon, color }) {

  const isPositiveBad = trend > 0 // rising = bad for CPU/memory
  const trendColor = isPositiveBad ? 'text-red-400' : 'text-green-400'
  const trendArrow = trend > 0 ? '▲' : '▼'

  // Color themes
  const themes = {
    cyan:   { border: 'border-cyan-500/30',   glow: 'shadow-cyan-500/10',   text: 'text-cyan-400',   bg: 'bg-cyan-500/10'   },
    purple: { border: 'border-purple-500/30', glow: 'shadow-purple-500/10', text: 'text-purple-400', bg: 'bg-purple-500/10' },
    orange: { border: 'border-orange-500/30', glow: 'shadow-orange-500/10', text: 'text-orange-400', bg: 'bg-orange-500/10' },
    green:  { border: 'border-green-500/30',  glow: 'shadow-green-500/10',  text: 'text-green-400',  bg: 'bg-green-500/10'  },
  }

  const t = themes[color] || themes.cyan

  // Bar width capped at 100%
  const barWidth = Math.min(value, 100)

  return (
    <div className={`bg-[#0d1327] border ${t.border} rounded-xl p-4 shadow-lg ${t.glow} flex flex-col gap-3`}>

      {/* Top row */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className={`text-lg ${t.bg} p-1.5 rounded-lg`}>{icon}</span>
          <span className="text-gray-400 text-xs font-medium uppercase tracking-wider">{title}</span>
        </div>
        <span className={`text-xs ${trendColor} font-mono`}>
          {trendArrow} {Math.abs(trend)}{unit === '%' ? '%' : ''}
        </span>
      </div>

      {/* Value */}
      <div className="flex items-end gap-1">
        <span className={`text-3xl font-bold font-mono ${t.text}`}>
          {value}
        </span>
        <span className="text-gray-500 text-sm mb-1">{unit}</span>
      </div>

      {/* Progress bar */}
      <div className="w-full bg-white/5 rounded-full h-1.5">
        <div
          className={`h-1.5 rounded-full transition-all duration-700 ${t.text.replace('text', 'bg')}`}
          style={{ width: `${barWidth}%` }}
        />
      </div>

      {/* Bottom */}
      <div className="text-xs text-gray-500">
        Top consumer: <span className="text-gray-300 font-mono">{topPod}</span>
      </div>

    </div>
  )
}
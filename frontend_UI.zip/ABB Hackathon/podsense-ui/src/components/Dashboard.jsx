import MetricCard from './MetricCard'
import MetricsChart from './MetricsChart'
import DependencyMap from './DependencyMap'
import AIInsights from './AIInsights'
import AlertFeed from './AlertFeed'
import useMockMetrics from '../hooks/useMockMetrics'

export default function Dashboard() {
  const metrics = useMockMetrics(5000)

  const cards = [
    { title: 'CPU Usage',    icon: '⚡', color: 'cyan',   ...metrics.cpu     },
    { title: 'Memory Usage', icon: '🧠', color: 'purple', ...metrics.memory  },
    { title: 'PVC I/O',      icon: '💾', color: 'orange', ...metrics.pvc     },
    { title: 'Network',      icon: '🌐', color: 'green',  ...metrics.network },
  ]

  return (
    <div className="grid grid-cols-12 gap-4">

      {/* Metric Cards */}
      <div className="col-span-12 grid grid-cols-4 gap-4">
        {cards.map((card) => (
          <MetricCard key={card.title} {...card} />
        ))}
      </div>

      {/* Charts + Dependency Map */}
      <div className="col-span-8 bg-[#0d1327] border border-cyan-900/30 rounded-xl p-4 min-h-[280px]">
        <MetricsChart />
      </div>
      <div className="col-span-4 bg-[#0d1327] border border-cyan-900/30 rounded-xl p-4 min-h-[280px]">
        <DependencyMap />
      </div>

      {/* Bottom row */}
      <div className="col-span-6 bg-[#0d1327] border border-cyan-900/30 rounded-xl p-4 min-h-[220px]">
        <AIInsights />
      </div>
      <div className="col-span-6 bg-[#0d1327] border border-cyan-900/30 rounded-xl p-4 min-h-[220px]">
        <AlertFeed />
      </div>

    </div>
  )
}
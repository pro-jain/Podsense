import { useState, useEffect } from 'react'
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid,
  Tooltip, Legend, ResponsiveContainer
} from 'recharts'

function generatePoint(prev) {
  const clamp = (val, min, max) => Math.min(max, Math.max(min, val))
  const nudge = (val, min, max, delta) =>
    clamp(+(val + (Math.random() - 0.48) * delta).toFixed(1), min, max)

  return {
    time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    cpu:     nudge(prev?.cpu     ?? 45, 10, 95, 8),
    memory:  nudge(prev?.memory  ?? 50, 20, 85, 5),
    pvc:     nudge(prev?.pvc     ?? 300, 80, 900, 60),
    network: nudge(prev?.network ?? 150, 20, 400, 30),
  }
}

// Custom tooltip
function CustomTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-[#0a0f1e] border border-cyan-900/40 rounded-lg p-3 text-xs shadow-xl">
      <p className="text-gray-400 mb-2">{label}</p>
      {payload.map((p) => (
        <div key={p.name} className="flex items-center gap-2 mb-1">
          <span style={{ color: p.color }}>●</span>
          <span className="text-gray-300">{p.name}:</span>
          <span style={{ color: p.color }} className="font-mono font-bold">{p.value}</span>
        </div>
      ))}
    </div>
  )
}

const LINES = [
  { key: 'cpu',     name: 'CPU %',     color: '#22d3ee' }, // cyan
  { key: 'memory',  name: 'Memory %',  color: '#a855f7' }, // purple
]

const LINES2 = [
  { key: 'pvc',     name: 'PVC MB/s',  color: '#f97316' }, // orange
  { key: 'network', name: 'Net Mbps',  color: '#4ade80' }, // green
]

function MiniChart({ lines, data, title }) {
  return (
    <div className="flex-1">
      <p className="text-gray-500 text-xs uppercase tracking-wider mb-2">{title}</p>
      <ResponsiveContainer width="100%" height={100}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#1e2a45" />
          <XAxis dataKey="time" tick={{ fill: '#4b5563', fontSize: 9 }} tickLine={false} interval="preserveStartEnd" />
          <YAxis tick={{ fill: '#4b5563', fontSize: 9 }} tickLine={false} axisLine={false} width={32} />
          <Tooltip content={<CustomTooltip />} />
          {lines.map(l => (
            <Line
              key={l.key}
              type="monotone"
              dataKey={l.key}
              name={l.name}
              stroke={l.color}
              strokeWidth={2}
              dot={false}
              isAnimationActive={true}
              animationDuration={400}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}

export default function MetricsChart() {
  const [history, setHistory] = useState(() => {
    // Seed 20 initial points so chart isn't empty on load
    const points = []
    let prev = null
    for (let i = 0; i < 20; i++) {
      const p = generatePoint(prev)
      points.push(p)
      prev = p
    }
    return points
  })

  useEffect(() => {
    const timer = setInterval(() => {
      setHistory(prev => {
        const next = generatePoint(prev[prev.length - 1])
        const updated = [...prev, next]
        return updated.length > 30 ? updated.slice(-30) : updated // keep last 30 points
      })
    }, 5000)
    return () => clearInterval(timer)
  }, [])

  return (
    <div className="flex flex-col gap-4 h-full">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-white text-sm font-semibold">Resource Timeline</h2>
          <p className="text-gray-500 text-xs">Last 30 data points • 5s interval</p>
        </div>
        <div className="flex gap-3 text-xs">
          {[...LINES, ...LINES2].map(l => (
            <span key={l.key} className="flex items-center gap-1 text-gray-400">
              <span style={{ color: l.color }}>─</span> {l.name}
            </span>
          ))}
        </div>
      </div>

      {/* Charts */}
      <div className="flex flex-col gap-4 flex-1">
        <MiniChart lines={LINES}  data={history} title="CPU & Memory (%)" />
        <MiniChart lines={LINES2} data={history} title="PVC I/O & Network" />
      </div>
    </div>
  )
}
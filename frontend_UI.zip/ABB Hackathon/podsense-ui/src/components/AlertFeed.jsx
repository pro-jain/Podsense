import { useState, useEffect } from 'react'

const ALERT_POOL = [
  { severity: 'critical', pod: 'postgres-db',   namespace: 'default',     message: 'Memory usage exceeded 75% threshold' },
  { severity: 'critical', pod: 'api-gateway',   namespace: 'default',     message: 'CPU spike detected — 87% for >60s' },
  { severity: 'warning',  pod: 'redis-cache',   namespace: 'default',     message: 'PVC write throughput 2.3x above baseline' },
  { severity: 'warning',  pod: 'orders-svc',    namespace: 'production',  message: 'Response latency increased to 320ms' },
  { severity: 'warning',  pod: 'auth-svc',      namespace: 'production',  message: 'Elevated error rate — 4.2% of requests' },
  { severity: 'info',     pod: 'notify-svc',    namespace: 'default',     message: 'Traffic surge detected — 40% above normal' },
  { severity: 'info',     pod: 'ingress-nginx', namespace: 'kube-system', message: 'Connection pool at 68% capacity' },
  { severity: 'critical', pod: 'postgres-db',   namespace: 'default',     message: 'OOMKill risk — estimated 12 min at current rate' },
  { severity: 'warning',  pod: 'frontend-svc',  namespace: 'production',  message: 'Network Mbps approaching node limit' },
  { severity: 'info',     pod: 'redis-cache',   namespace: 'default',     message: 'Eviction policy triggered — maxmemory reached' },
]

const SEV = {
  critical: { dot: 'bg-red-400',    text: 'text-red-400',    border: 'border-red-500/20',    bg: 'bg-red-500/5',    label: 'CRIT' },
  warning:  { dot: 'bg-yellow-400', text: 'text-yellow-400', border: 'border-yellow-500/20', bg: 'bg-yellow-500/5', label: 'WARN' },
  info:     { dot: 'bg-cyan-400',   text: 'text-cyan-400',   border: 'border-cyan-500/20',   bg: 'bg-cyan-500/5',   label: 'INFO' },
}

function timeAgo(date) {
  const seconds = Math.floor((Date.now() - date) / 1000)
  if (seconds < 10) return 'just now'
  if (seconds < 60) return `${seconds}s ago`
  return `${Math.floor(seconds / 60)}m ago`
}

function randomAlert() {
  const base = ALERT_POOL[Math.floor(Math.random() * ALERT_POOL.length)]
  return { ...base, id: Date.now() + Math.random(), time: Date.now() }
}

export default function AlertFeed() {
  const [alerts, setAlerts] = useState(() =>
    Array.from({ length: 6 }, (_, i) => ({
      ...ALERT_POOL[i],
      id: i,
      time: Date.now() - (6 - i) * 8000,
    }))
  )
  const [tick, setTick] = useState(0)

  useEffect(() => {
    const timer = setInterval(() => {
      setAlerts(prev => [randomAlert(), ...prev].slice(0, 20))
    }, 6000)
    return () => clearInterval(timer)
  }, [])

  useEffect(() => {
    const timer = setInterval(() => setTick(t => t + 1), 5000)
    return () => clearInterval(timer)
  }, [])

  const critCount = alerts.filter(a => a.severity === 'critical').length
  const warnCount = alerts.filter(a => a.severity === 'warning').length

  return (
    <div className="flex flex-col h-full gap-3">

      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-white text-sm font-semibold">Alert Feed</h2>
          <p className="text-gray-500 text-xs">Live anomaly events • All namespaces</p>
        </div>
        <div className="flex gap-2 text-xs">
          <span className="bg-red-500/10 text-red-400 border border-red-500/20 px-2 py-1 rounded-full">
            {critCount} critical
          </span>
          <span className="bg-yellow-500/10 text-yellow-400 border border-yellow-500/20 px-2 py-1 rounded-full">
            {warnCount} warn
          </span>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto flex flex-col gap-1.5 pr-1">
        {alerts.map((alert, i) => {
          const s = SEV[alert.severity]
          const isNew = i === 0
          return (
            <div
              key={alert.id}
              className={`flex items-start gap-3 p-2.5 rounded-lg border ${s.border} ${s.bg}`}
            >
              <div className="mt-1 shrink-0">
                <span className={`block w-2 h-2 rounded-full ${s.dot}`} />
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  <span className={`text-xs font-mono font-bold ${s.text}`}>
                    {s.label}
                  </span>
                  <span className="text-gray-300 text-xs font-mono truncate">
                    {alert.pod}
                  </span>
                  <span className="text-gray-600 text-xs ml-auto shrink-0">
                    {timeAgo(alert.time)}
                  </span>
                </div>
                <p className="text-gray-400 text-xs leading-relaxed">
                  {alert.message}
                </p>
                <span className="text-gray-600 text-xs font-mono">
                  ns: {alert.namespace}
                </span>
              </div>
            </div>
          )
        })}
      </div>

    </div>
  )
}
import { useState, useEffect, useRef } from 'react'

const INSIGHTS = [
  {
    agent: 'CPU Agent',
    icon: '⚡',
    color: '#22d3ee',
    severity: 'warning',
    message: 'api-gateway CPU spiked to 87% at 04:01:32. Correlates with ingress traffic surge of 3x normal volume. Recommend horizontal pod autoscaling.',
  },
  {
    agent: 'Memory Agent',
    icon: '🧠',
    color: '#a855f7',
    severity: 'critical',
    message: 'postgres-db memory climbing steadily — 61% → 74% over 8 minutes. Pattern matches slow memory leak. OOMKill risk in ~12 minutes at current rate.',
  },
  {
    agent: 'PVC Agent',
    icon: '💾',
    color: '#f97316',
    severity: 'info',
    message: 'redis-cache PVC write throughput is 890 MB/s — 2.3x above baseline. orders-svc is the primary writer. No anomaly, but monitor for I/O saturation.',
  },
  {
    agent: 'Network Agent',
    icon: '🌐',
    color: '#4ade80',
    severity: 'info',
    message: 'Detected bidirectional traffic between orders-svc and notify-svc increasing 40% in last 5 minutes. Likely order processing surge. No action needed.',
  },
  {
    agent: 'Orchestrator',
    icon: '🤖',
    color: '#f59e0b',
    severity: 'critical',
    message: 'Root cause identified: postgres-db memory leak is cascading — auth-svc and orders-svc response times up 320ms. Blast radius: 3 pods affected. Auto-generating remediation manifest.',
  },
]

const SEVERITY_STYLES = {
  info:     { bg: 'bg-cyan-500/10',   border: 'border-cyan-500/20',   text: 'text-cyan-400',   label: 'INFO'     },
  warning:  { bg: 'bg-yellow-500/10', border: 'border-yellow-500/20', text: 'text-yellow-400', label: 'WARN'     },
  critical: { bg: 'bg-red-500/10',    border: 'border-red-500/20',    text: 'text-red-400',    label: 'CRITICAL' },
}

function useTypewriter(text, speed = 18) {
  const [displayed, setDisplayed] = useState('')
  const indexRef = useRef(0)

  useEffect(() => {
    setDisplayed('')
    indexRef.current = 0

    const timer = setInterval(() => {
      if (indexRef.current < text.length) {
        setDisplayed(text.slice(0, indexRef.current + 1))
        indexRef.current++
      } else {
        clearInterval(timer)
      }
    }, speed)

    return () => clearInterval(timer)
  }, [text, speed])

  return displayed
}

export default function AIInsights() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isTyping, setIsTyping]         = useState(true)

  const insight = INSIGHTS[currentIndex]
  const sev     = SEVERITY_STYLES[insight.severity]
  const typed   = useTypewriter(insight.message, 18)

  // Advance to next insight after message finishes + 2s pause
  useEffect(() => {
    const msgDuration = insight.message.length * 18 + 2000
    const timer = setTimeout(() => {
      setCurrentIndex(i => (i + 1) % INSIGHTS.length)
    }, msgDuration)
    return () => clearTimeout(timer)
  }, [currentIndex, insight.message.length])

  return (
    <div className="flex flex-col h-full gap-3">

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-white text-sm font-semibold">AI Agent Insights</h2>
          <p className="text-gray-500 text-xs">Multi-agent consensus • Real-time analysis</p>
        </div>
        <div className="flex gap-1">
          {INSIGHTS.map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrentIndex(i)}
              className={`w-2 h-2 rounded-full transition-all ${
                i === currentIndex ? 'bg-cyan-400 w-4' : 'bg-gray-700'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Agent card */}
      <div className={`flex-1 ${sev.bg} border ${sev.border} rounded-xl p-4 flex flex-col gap-3 transition-all duration-500`}>

        {/* Agent header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-lg">{insight.icon}</span>
            <span style={{ color: insight.color }} className="font-semibold text-sm">
              {insight.agent}
            </span>
          </div>
          <span className={`text-xs font-mono px-2 py-0.5 rounded-full border ${sev.border} ${sev.text} ${sev.bg}`}>
            {sev.label}
          </span>
        </div>

        {/* Typewriter message */}
        <p className="text-gray-300 text-sm leading-relaxed flex-1">
          {typed}
          <span className="inline-block w-0.5 h-4 bg-cyan-400 ml-0.5 animate-pulse align-middle" />
        </p>

        {/* Footer */}
        <div className="flex items-center justify-between text-xs text-gray-600">
          <span>Agent {currentIndex + 1} of {INSIGHTS.length}</span>
          <span className="text-gray-500">
            {new Date().toLocaleTimeString()}
          </span>
        </div>
      </div>

      {/* Quick agent status row */}
      <div className="grid grid-cols-5 gap-1">
        {INSIGHTS.map((ins, i) => (
          <button
            key={i}
            onClick={() => setCurrentIndex(i)}
            className={`text-center py-1.5 px-1 rounded-lg border text-xs transition-all ${
              i === currentIndex
                ? 'border-cyan-500/40 bg-cyan-500/10 text-cyan-400'
                : 'border-white/5 bg-white/3 text-gray-600 hover:text-gray-400'
            }`}
          >
            <div>{ins.icon}</div>
            <div className="text-[9px] mt-0.5 truncate">{ins.agent.split(' ')[0]}</div>
          </button>
        ))}
      </div>

    </div>
  )
}
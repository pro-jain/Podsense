const navItems = [
  { icon: '⬡', label: 'Overview', active: true },
  { icon: '📊', label: 'Metrics' },
  { icon: '🔗', label: 'Dependencies' },
  { icon: '🤖', label: 'AI Insights' },
  { icon: '🚨', label: 'Alerts' },
  { icon: '⚙️', label: 'Settings' },
]

export default function Sidebar() {
  return (
    <div className="w-56 bg-[#0d1327] border-r border-cyan-900/40 flex flex-col py-6 px-4 gap-2 shrink-0">
      {/* Logo */}
      <div className="mb-8 px-2">
        <div className="text-cyan-400 font-bold text-xl tracking-wide">
          Pod<span className="text-white">Sense</span>
          <span className="text-cyan-400 text-xs ml-1 font-normal">AI</span>
        </div>
        <div className="text-gray-500 text-xs mt-1">K8s Intelligence Layer</div>
      </div>

      {/* Nav */}
      {navItems.map((item) => (
        <button
          key={item.label}
          className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all
            ${item.active
              ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30'
              : 'text-gray-400 hover:text-white hover:bg-white/5'
            }`}
        >
          <span className="text-base">{item.icon}</span>
          {item.label}
        </button>
      ))}

      {/* Bottom status */}
      <div className="mt-auto px-2">
        <div className="flex items-center gap-2 text-xs text-gray-500">
          <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></span>
          Cluster: minikube
        </div>
        <div className="text-xs text-gray-600 mt-1">Node: Ready ✓</div>
      </div>
    </div>
  )
}
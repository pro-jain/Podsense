import { useState, useEffect } from 'react'

const PODS = [
  { id: 'ingress',     label: 'ingress-nginx',  x: 160, y: 50,  color: '#22d3ee', ring: '#22d3ee33' },
  { id: 'api',         label: 'api-gateway',    x: 160, y: 150, color: '#a855f7', ring: '#a855f733' },
  { id: 'auth',        label: 'auth-svc',       x: 60,  y: 250, color: '#22d3ee', ring: '#22d3ee33' },
  { id: 'orders',      label: 'orders-svc',     x: 160, y: 250, color: '#22d3ee', ring: '#22d3ee33' },
  { id: 'notify',      label: 'notify-svc',     x: 260, y: 250, color: '#22d3ee', ring: '#22d3ee33' },
  { id: 'postgres',    label: 'postgres-db',    x: 80,  y: 360, color: '#f97316', ring: '#f9731633' },
  { id: 'redis',       label: 'redis-cache',    x: 240, y: 360, color: '#4ade80', ring: '#4ade8033' },
]

const EDGES = [
  { from: 'ingress', to: 'api' },
  { from: 'api',     to: 'auth' },
  { from: 'api',     to: 'orders' },
  { from: 'api',     to: 'notify' },
  { from: 'auth',    to: 'postgres' },
  { from: 'orders',  to: 'postgres' },
  { from: 'orders',  to: 'redis' },
  { from: 'notify',  to: 'redis' },
]

function getPos(id) {
  return PODS.find(p => p.id === id)
}

export default function DependencyMap() {
  const [activePod, setActivePod] = useState(null)
  const [anomaly, setAnomaly] = useState('postgres')
  const [pulse, setPulse] = useState(0)

  // Rotate which pod has anomaly every 4s
  useEffect(() => {
    const ids = PODS.map(p => p.id)
    const timer = setInterval(() => {
      setAnomaly(ids[Math.floor(Math.random() * ids.length)])
      setPulse(v => v + 1)
    }, 4000)
    return () => clearInterval(timer)
  }, [])

  const activePodData = activePod ? PODS.find(p => p.id === activePod) : null
  const activeEdges = activePod
    ? EDGES.filter(e => e.from === activePod || e.to === activePod)
    : []

  return (
    <div className="flex flex-col h-full gap-3">
      {/* Header */}
      <div>
        <h2 className="text-white text-sm font-semibold">Dependency Map</h2>
        <p className="text-gray-500 text-xs">Click a pod to trace connections</p>
      </div>

      {/* SVG Graph */}
      <div className="flex-1 relative">
        <svg
          viewBox="0 0 320 420"
          className="w-full h-full"
          style={{ maxHeight: '340px' }}
        >
          {/* Edges */}
          {EDGES.map((edge, i) => {
            const from = getPos(edge.from)
            const to   = getPos(edge.to)
            const isActive = activeEdges.some(
              e => e.from === edge.from && e.to === edge.to
            )
            return (
              <line
                key={i}
                x1={from.x} y1={from.y}
                x2={to.x}   y2={to.y}
                stroke={isActive ? '#22d3ee' : '#1e3a5f'}
                strokeWidth={isActive ? 2 : 1}
                strokeDasharray={isActive ? '5 3' : 'none'}
                opacity={isActive ? 1 : 0.5}
              />
            )
          })}

          {/* Nodes */}
          {PODS.map(pod => {
            const isAnomaly = pod.id === anomaly
            const isSelected = pod.id === activePod
            return (
              <g
                key={pod.id}
                onClick={() => setActivePod(pod.id === activePod ? null : pod.id)}
                style={{ cursor: 'pointer' }}
              >
                {/* Pulse ring for anomaly */}
                {isAnomaly && (
                  <circle
                    cx={pod.x} cy={pod.y} r={22}
                    fill="none"
                    stroke="#ef4444"
                    strokeWidth={1.5}
                    opacity={0.6}
                  >
                    <animate
                      attributeName="r"
                      values="18;26;18"
                      dur="1.5s"
                      repeatCount="indefinite"
                    />
                    <animate
                      attributeName="opacity"
                      values="0.8;0;0.8"
                      dur="1.5s"
                      repeatCount="indefinite"
                    />
                  </circle>
                )}

                {/* Selection ring */}
                {isSelected && (
                  <circle
                    cx={pod.x} cy={pod.y} r={20}
                    fill="none"
                    stroke={pod.color}
                    strokeWidth={2}
                    opacity={0.8}
                  />
                )}

                {/* Main node circle */}
                <circle
                  cx={pod.x} cy={pod.y} r={14}
                  fill={pod.ring}
                  stroke={isAnomaly ? '#ef4444' : pod.color}
                  strokeWidth={isSelected ? 2 : 1.5}
                />

                {/* Pod initial letter */}
                <text
                  x={pod.x} y={pod.y + 5}
                  textAnchor="middle"
                  fill={isAnomaly ? '#ef4444' : pod.color}
                  fontSize="11"
                  fontWeight="bold"
                  fontFamily="monospace"
                >
                  {pod.label[0].toUpperCase()}
                </text>

                {/* Label below */}
                <text
                  x={pod.x} y={pod.y + 28}
                  textAnchor="middle"
                  fill="#9ca3af"
                  fontSize="8"
                  fontFamily="monospace"
                >
                  {pod.label}
                </text>
              </g>
            )
          })}
        </svg>
      </div>

      {/* Info panel — shows on click */}
      {activePodData ? (
        <div className="bg-[#0a0f1e] border border-cyan-900/30 rounded-lg p-3 text-xs">
          <div className="flex items-center gap-2 mb-2">
            <span style={{ color: activePodData.color }}>●</span>
            <span className="text-white font-mono font-semibold">{activePodData.label}</span>
            {activePodData.id === anomaly && (
              <span className="ml-auto text-red-400 bg-red-500/10 border border-red-500/20 px-2 py-0.5 rounded-full">
                ⚠ Anomaly
              </span>
            )}
          </div>
          <div className="text-gray-500">
            Connected to{' '}
            <span className="text-cyan-400">
              {activeEdges.length} pod{activeEdges.length !== 1 ? 's' : ''}
            </span>
          </div>
          <div className="mt-1 text-gray-600">
            {activeEdges.map((e, i) => {
              const other = e.from === activePod ? e.to : e.from
              const dir   = e.from === activePod ? '→' : '←'
              return (
                <span key={i} className="mr-2 text-gray-400 font-mono">
                  {dir} {other}
                </span>
              )
            })}
          </div>
        </div>
      ) : (
        <div className="text-center text-gray-600 text-xs py-2">
          Click any node to inspect connections
        </div>
      )}

    </div>
  )
}
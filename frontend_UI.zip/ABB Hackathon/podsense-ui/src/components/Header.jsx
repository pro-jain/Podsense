export default function Header() {
  const now = new Date().toLocaleTimeString()

  return (
    <div className="h-14 bg-[#0d1327] border-b border-cyan-900/40 flex items-center justify-between px-6 shrink-0">
      <div>
        <h1 className="text-white font-semibold text-base">
          Real-Time Pod Intelligence
        </h1>
        <p className="text-gray-500 text-xs">
          Monitoring all namespaces • Auto-refresh every 5s
        </p>
      </div>

      <div className="flex items-center gap-4">
        <div className="text-xs text-gray-400 bg-white/5 px-3 py-1.5 rounded-full border border-white/10">
          🕐 {now}
        </div>
        <div className="text-xs bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 px-3 py-1.5 rounded-full">
          5 Agents Active
        </div>
        <div className="text-xs bg-green-500/10 text-green-400 border border-green-500/30 px-3 py-1.5 rounded-full">
          ● Live
        </div>
      </div>
    </div>
  )
}